package com.dashboard.custom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomApplicationTests {

	@Test
	void contextLoads() {
	}

}
